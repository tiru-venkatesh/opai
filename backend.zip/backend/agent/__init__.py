"""OPA agent architecture package."""
