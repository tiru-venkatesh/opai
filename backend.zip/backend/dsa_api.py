"""DSA Roadmap endpoints: /v1/dsa*. Planning and tracking only; no problems, judge, editor or solutions."""
from __future__ import annotations

from datetime import date, timedelta
from typing import List, Literal, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

import dsa_service as S
from audit.logger import record as audit
from database import DsaSession, User, get_db

router = APIRouter()


def _user(db: Session, user_id: str) -> str:
    uid = str(user_id)
    if not db.query(User).filter(User.id == uid).first():
        raise HTTPException(404, "User not found")
    return uid


def _wrap(fn, *a, **k):
    try:
        return fn(*a, **k)
    except S.DsaError as e:
        raise HTTPException(e.status, e.detail)


@router.get("/v1/dsa")
def get_dsa(user_id: str, db: Session = Depends(get_db)):
    return S.state(db, _user(db, user_id))


class PlanBody(BaseModel):
    user_id: str
    goal: str = "Placement preparation"
    language: str = "Python"
    level: str = "Starting from basics"
    daily_minutes: int = Field(default=60, ge=20, le=180)
    days_per_week: int = Field(default=5, ge=1, le=7)
    target_date: Optional[date] = None


@router.post("/v1/dsa/plan")
def create_plan(p: PlanBody, db: Session = Depends(get_db)):
    """Creates the phase-based roadmap (replaces any existing one)."""
    uid = _user(db, p.user_id)
    _wrap(S.create_plan, db, uid, p.goal, p.language, p.daily_minutes, p.days_per_week, level=p.level, target_date=p.target_date)
    audit(db, uid, "dsa.plan_created", {"goal": p.goal, "language": p.language, "level": p.level, "daily_minutes": p.daily_minutes}, {"ok": True}, "low")
    return S.state(db, uid)


class SettingsBody(BaseModel):
    user_id: str
    mode_override: Optional[str] = None
    daily_minutes: Optional[int] = Field(default=None, ge=20, le=180)
    days_per_week: Optional[int] = Field(default=None, ge=1, le=7)
    target_date: Optional[date] = None        # send null to clear
    resources: Optional[dict] = None          # {"learn": {"source": "YouTube"}, "practice": {...}, "notes": {...}}


@router.patch("/v1/dsa/plan")
def patch_plan(p: SettingsBody, db: Session = Depends(get_db)):
    uid = _user(db, p.user_id)
    _wrap(S.update_settings, db, uid, p.model_dump(exclude={"user_id"}, exclude_unset=True))
    return S.state(db, uid)


@router.delete("/v1/dsa/plan")
def delete_plan(user_id: str, db: Session = Depends(get_db)):
    uid = _user(db, user_id)
    S.delete_plan(db, uid)
    audit(db, uid, "dsa.plan_deleted", {}, {"ok": True}, "low")
    return S.state(db, uid)


class TopicPatch(BaseModel):
    user_id: str
    status: Optional[str] = None
    confidence: Optional[int] = Field(default=None, ge=1, le=5)
    learn_url: Optional[str] = Field(default=None, max_length=500)
    practice_url: Optional[str] = Field(default=None, max_length=500)
    notes: Optional[str] = Field(default=None, max_length=2000)


@router.patch("/v1/dsa/topics/{topic_id}")
def patch_topic(topic_id: str, p: TopicPatch, db: Session = Depends(get_db)):
    uid = _user(db, p.user_id)
    _wrap(S.update_topic, db, uid, topic_id, p.model_dump(exclude={"user_id"}, exclude_unset=True))
    return S.state(db, uid)


class CompleteBody(BaseModel):
    user_id: str
    actual_minutes: Optional[int] = Field(default=None, ge=1, le=600)
    confidence: Optional[int] = Field(default=None, ge=1, le=5)
    outcome: Literal["completed", "partial", "could_not_start"] = "completed"
    difficulty: List[str] = Field(default_factory=list, max_length=5)


@router.post("/v1/dsa/sessions/{session_id}/complete")
def complete(session_id: str, p: CompleteBody, db: Session = Depends(get_db)):
    uid = _user(db, p.user_id)
    _wrap(S.complete_session, db, uid, session_id, p.actual_minutes, p.confidence, p.outcome, p.difficulty)
    return S.state(db, uid)


class ReviewBody(BaseModel):
    user_id: str
    confidence: int = Field(ge=1, le=5)
    actual_minutes: Optional[int] = Field(default=None, ge=1, le=600)


@router.post("/v1/dsa/topics/{topic_id}/review")
def review(topic_id: str, p: ReviewBody, db: Session = Depends(get_db)):
    """Log a spaced revision from the Revision Queue. Confidence sets the next review date."""
    uid = _user(db, p.user_id)
    _wrap(S.review_topic, db, uid, topic_id, p.confidence, p.actual_minutes)
    return S.state(db, uid)


class UserBody(BaseModel):
    user_id: str


@router.post("/v1/dsa/sessions/{session_id}/skip")
def skip(session_id: str, p: UserBody, db: Session = Depends(get_db)):
    uid = _user(db, p.user_id)
    _wrap(S.skip_session, db, uid, session_id)
    return S.state(db, uid)

@router.get("/v1/dsa/streak")
def dsa_streak(user_id: str, db: Session = Depends(get_db)):
    """Streak over PLANNED days only (rest days never break it). Today stays open until it ends."""
    uid = _user(db, user_id)
    today = date.today()
    rows = (db.query(DsaSession).filter(DsaSession.user_id == uid, DsaSession.plan_date <= today)
            .order_by(DsaSession.plan_date.desc()).all())
    today_row = next((r for r in rows if r.plan_date == today), None)
    past = [r for r in rows if r.plan_date < today]
    current = 0
    for r in past:
        if r.status != "done":
            break
        current += 1
    today_done = bool(today_row and today_row.status == "done")
    if today_done:
        current += 1
    longest = run = 0
    for r in reversed(past + ([today_row] if today_done else [])):
        run = run + 1 if r.status == "done" else 0
        longest = max(longest, run)
    missed = lost = 0
    if past and past[0].status != "done":
        i = 0
        while i < len(past) and past[i].status != "done":
            missed += 1
            i += 1
        while i < len(past) and past[i].status == "done":
            lost += 1
            i += 1
    today_status = today_row.status if today_row else "rest_day"
    return {"current": current, "longest": longest, "today_status": today_status,
            "at_risk": bool(today_row and not today_done and current > 0),
            "lost_streak": lost if (missed and not today_done) else 0, "missed_days": missed if not today_done else 0}
